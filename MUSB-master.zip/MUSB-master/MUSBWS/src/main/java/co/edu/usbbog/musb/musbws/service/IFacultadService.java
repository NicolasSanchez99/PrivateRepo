package co.edu.usbbog.musb.musbws.service;

import co.edu.usbbog.musb.musbws.model.Facultad;

public interface IFacultadService {
	public String crearFacultad(Facultad facultad);
}
