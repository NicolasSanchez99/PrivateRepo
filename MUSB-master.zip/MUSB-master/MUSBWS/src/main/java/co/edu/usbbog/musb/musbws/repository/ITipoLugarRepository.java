package co.edu.usbbog.musb.musbws.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.usbbog.musb.musbws.model.TipoLugar;

public interface ITipoLugarRepository extends JpaRepository<TipoLugar, Integer>{

}
