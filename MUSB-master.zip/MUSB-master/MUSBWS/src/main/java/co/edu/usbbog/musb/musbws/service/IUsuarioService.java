package co.edu.usbbog.musb.musbws.service;

import co.edu.usbbog.musb.musbws.model.Usuario;

public interface IUsuarioService {
	public String crearUsuario(Usuario usuario);
}
