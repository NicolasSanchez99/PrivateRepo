package co.edu.usbbog.musb.musbws.service;

import co.edu.usbbog.musb.musbws.model.Chat;

public interface IChatService {
	public String crearChat(Chat chat);
}
