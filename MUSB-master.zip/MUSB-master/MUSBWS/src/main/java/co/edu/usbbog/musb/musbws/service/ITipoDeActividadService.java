package co.edu.usbbog.musb.musbws.service;

import co.edu.usbbog.musb.musbws.model.TipoActividad;

public interface ITipoDeActividadService {
	public String crearTipoDeActividad(TipoActividad tactividad);
}
