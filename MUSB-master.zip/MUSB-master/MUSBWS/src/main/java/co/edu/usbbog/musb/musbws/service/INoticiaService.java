package co.edu.usbbog.musb.musbws.service;

import co.edu.usbbog.musb.musbws.model.Noticia;

public interface INoticiaService {
	public String crearNoticia(Noticia noticia);
}
