package co.edu.usbbog.musb.musbws.service;

import co.edu.usbbog.musb.musbws.model.Amigo;

public interface IAmigoService {
	public String crearAmigo(Amigo amigo);
}
