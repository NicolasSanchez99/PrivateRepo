package co.edu.usbbog.musb.musbws.service;

import co.edu.usbbog.musb.musbws.model.Lugar;

public interface ILugarService {
	public String crearLugar(Lugar lugar);
}
