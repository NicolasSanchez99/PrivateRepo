package co.edu.usbbog.musb.musbws.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.usbbog.musb.musbws.model.Evento;

public interface IEventoRepository extends JpaRepository<Evento, Integer>{

}
