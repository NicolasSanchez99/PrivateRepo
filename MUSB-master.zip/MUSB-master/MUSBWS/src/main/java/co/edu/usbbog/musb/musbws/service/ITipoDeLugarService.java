package co.edu.usbbog.musb.musbws.service;


import co.edu.usbbog.musb.musbws.model.TipoLugar;

public interface ITipoDeLugarService {
	public String crearTipoDeLugar(TipoLugar tipoLugar);
}
