package co.edu.usbbog.musb.musbws.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import co.edu.usbbog.musb.musbws.model.Sede;

public interface ISedeRepository extends JpaRepository<Sede, Integer>{
	
}
