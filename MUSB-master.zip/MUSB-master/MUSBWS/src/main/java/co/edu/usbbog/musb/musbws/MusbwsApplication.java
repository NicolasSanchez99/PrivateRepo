package co.edu.usbbog.musb.musbws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusbwsApplication {	

	public static void main(String[] args) {
		SpringApplication.run(MusbwsApplication.class, args);
	}

}
