package co.edu.usbbog.musb.musbws.service;

import co.edu.usbbog.musb.musbws.model.Evento;

public interface IEventoService {
	public String crearEvento(Evento evento);
}
