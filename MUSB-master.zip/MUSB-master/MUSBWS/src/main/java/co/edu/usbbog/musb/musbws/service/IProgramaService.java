package co.edu.usbbog.musb.musbws.service;
import co.edu.usbbog.musb.musbws.model.Programa;


public interface IProgramaService {
	public String crearPrograma(Programa programa);
}
