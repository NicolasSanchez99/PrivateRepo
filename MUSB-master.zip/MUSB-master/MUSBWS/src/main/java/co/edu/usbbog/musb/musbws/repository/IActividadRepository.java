package co.edu.usbbog.musb.musbws.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.usbbog.musb.musbws.model.Actividad;

public interface IActividadRepository extends JpaRepository<Actividad, Integer>{

}
