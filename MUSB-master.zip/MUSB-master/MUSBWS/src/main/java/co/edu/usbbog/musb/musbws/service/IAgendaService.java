package co.edu.usbbog.musb.musbws.service;

import co.edu.usbbog.musb.musbws.model.Agenda;

public interface IAgendaService {
	public String crearAgenda(Agenda agenda);
}
