package co.edu.usbbog.musb.musbws.service;

import co.edu.usbbog.musb.musbws.model.Actividad;

public interface IActividadService {
	public String crearActividad(Actividad actividad);
}
