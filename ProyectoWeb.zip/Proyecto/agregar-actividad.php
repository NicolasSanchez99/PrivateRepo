<?php
//1. Invocar conexión
include_once("conexion.php");
//2. Crear conexión a la Base de Datos
$con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
mysqli_set_charset($con,"utf8");

$vidGest = $_GET['cidGest'];
$vidPerf = $_GET['cidPerf'];
$vidActiv = $_GET['cidAct'];

    $inserta = "INSERT INTO $bd.gestactividad (idgestActividad, perfiles_id_perfil, actividades_id_actividades) VALUES ('$vidGest' , '$vidPerf', '$vidActiv')";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:PrincipalUser.php");


mysqli_close($con);
?>