<!DOCTYPE html>
<html lang="en">

<head>

     <title>Soft Landing Page by Tooplate</title>
     <!--

    Template 2106 Soft Landing

	http://www.tooplate.com/view/2106-soft-landing

    -->
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="team" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="2106_soft_landing/css/bootstrap.min.css">
     <link rel="stylesheet" href="2106_soft_landing/css/owl.carousel.css">
     <link rel="stylesheet" href="2106_soft_landing/css/owl.theme.default.min.css">
     <link rel="stylesheet" href="2106_soft_landing/css/font-awesome.min.css">
     <link rel="stylesheet" href="2106_soft_landing/css/Tablas.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="2106_soft_landing/css/tooplate-style.css">

</head>

<body>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>

          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="2106_soft_landing/index.html" class="navbar-brand">Home</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                         <li><a href="PrincipalUser.html" class="smoothScroll">Inicio</a></li>
                         <li><a href="Ventas.html" class="smoothScroll">Ventas</a></li>
                         <li><a href="Informacion de negocio.html" class="smoothScroll">Informacion de negocio</a></li>
                         <li><a href="Inventario.html" class="smoothScroll">Inventario</a></li>
                         <li><a href="Gastos.html" class="smoothScroll">Gastos</a></li>
                         <li><a href="Prestamos.html" class="smoothScroll">Prestamos</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="Index.html"><span>Usuario</span></a></li>
                    </ul>
               </div>

          </div>
     </section>







     <!-- PRICING -->
     <section id="Informacion" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h1>Informacion de tu negocio</h1>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="pricing-thumb">
                              <div class="pricing-title">
                                   <h2>Impuestos</h2>
                              </div>
                              <div class="pricing-info">
                                   <p>20 Responsive Designs</p>
                                   <p>10 Dashboards</p>
                                   <p>1 TB Storage</p>
                                   <p>6 TB Bandwidth</p>
                                   <p>24-hour Support</p>
                              </div>
                              <div class="pricing-bottom">
                                   <span class="pricing-dollar">$200/mo</span>
                                   <a href="#" class="section-btn pricing-btn">Register now</a>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="pricing-thumb">
                              <div class="pricing-title">
                                   <h2>Nomina</h2>
                              </div>
                              <div class="pricing-info">
                                   <p>50 Responsive Designs</p>
                                   <p>30 Dashboards</p>
                                   <p>2 TB Storage</p>
                                   <p>12 TB Bandwidth</p>
                                   <p>15-minute Support</p>
                              </div>
                              <div class="pricing-bottom">
                                   <span class="pricing-dollar">$350/mo</span>
                                   <a href="#" class="section-btn pricing-btn">Register now</a>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="pricing-thumb">
                              <div class="pricing-title">
                                   <h2>Productos</h2>
                              </div>
                              <div class="pricing-info">
                                   <p>100 Responsive Designs</p>
                                   <p>60 Dashboards</p>
                                   <p>5 TB Storage</p>
                                   <p>25 TB Bandwidth</p>
                                   <p>1-minute Support</p>
                              </div>
                              <div class="pricing-bottom">
                                   <span class="pricing-dollar">$550/mo</span>
                                   <a href="#" class="section-btn pricing-btn">Register now</a>
                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>


   

    

     <!-- FOOTER -->
     <footer id="footer" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="copyright-text col-md-12 col-sm-12">
                         <div class="col-md-6 col-sm-6">
                              <p>Copyright &copy; 2020 Semilla para mi negocio </p>
                         </div>

                         <div class="col-md-6 col-sm-6">
                              <ul class="social-icon">
                                   <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="#" class="fa fa-twitter"></a></li>
                                   <li><a href="#" class="fa fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>

               </div>
          </div>
     </footer>

     <!-- SCRIPTS -->
     <script src="2106_soft_landing/js/jquery.js"></script>
     <script src="2106_soft_landing/js/bootstrap.min.js"></script>
     <script src="2106_soft_landing/js/jquery.stellar.min.js"></script>
     <script src="2106_soft_landing/js/owl.carousel.min.js"></script>
     <script src="2106_soft_landing/js/smoothscroll.js"></script>
     <script src="2106_soft_landing/js/custom.js"></script>

</body>

</html>