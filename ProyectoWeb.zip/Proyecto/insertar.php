<?php
//1. Invocar conexión
include_once("conexion.php");
//2. Crear conexión a la Base de Datos
$con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
mysqli_set_charset($con,"utf8");

$vid = $_GET['cid'];
$vnombre = $_GET['cnomb'];
$vape = $_GET['cape'];
$vuser = $_GET['usuario'];
$vclve = $_GET['cclave'];
//$vperfil = $_GET['perfil'];
$vserial = $_GET['cod'];
$vtipo = $_GET['radio'];
// buscar para agregar radio
if($vtipo == 'administrador'){
   // $vperfil=1;
    $inserta = "INSERT INTO $bd.usuarios(cedula, nombres,apellidos, usuario, clave, perfiles_id_perfil,inventario_id_producto) VALUES ('$vid','$vnombre','$vape','$vuser','$vclve','1','$vserial');";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:PrincipalUser.php");
    
}
elseif($vtipo == 'usuario'){
    //$vperfil=2;
    $inserta = "INSERT INTO $bd.usuarios(cedula, nombres,apellidos, usuario, clave, perfiles_id_perfil,inventario_id_producto) VALUES ('$vid','$vnombre','$vape','$vuser','$vclve','2','$vserial');";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:PrincipalUser.php");
}

mysqli_close($con);
?>