<style>
table {
  table-layout: auto;
  width: 1000px;
}
</style>
<table border="1" cellspacing=5 cellpadding=5 style="font-size: 8pt"><tr>
<td><font face="verdana"><b>CEDULA</b></font></td>
<td><font face="verdana"><b>NOMBRE</b></font></td>
<td><font face="verdana"><b>APELLIDOS</b></font></td>
<td><font face="verdana"><b>USUARIO</b></font></td>
<td><font face="verdana"><b>PERFIL</b></font></td>
<td><font face="verdana"><b>EMPRESA</b></font></td>
</tr>

<?php  
    include_once("conexion.php");
    $con= new mysqli($host,$usuario,$clave,$bd) or die('Fallo la conexion');
    $result = $con->query("SELECT cedula,nombres,apellidos,usuario,perfiles_id_perfil,inventario_id_producto FROM $bd.usuarios");
  $numero = 0;
  while($row = mysqli_fetch_array($result))
  {
    echo "<tr><td width=\"10%\"><font face=\"verdana\">" . 
	    $row["cedula"] . "</font></td>";
    echo "<td width=\"10%\"><font face=\"verdana\">" . 
      $row["nombres"] . "</font></td>";
    echo "<td width=\"10%\"><font face=\"verdana\">" . 
	    $row["apellidos"] . "</font></td>";
    echo "<td width=\"10%\"><font face=\"verdana\">" . 
      $row["usuario"] . "</font></td>";
    echo "<td width=\"10%\"><font face=\"verdana\">" . 
	    $row["perfiles_id_perfil"] . "</font></td>";
    echo "<td width=\"10%\"><font face=\"verdana\">" . 
        $row["inventario_id_producto"]. "</font></td></tr>";      
    $numero++;
  }
  //echo "<tr><td colspan=\"10\"><font face=\"verdana\"><b>Número: " . $numero . 
      //"</b></font></td></tr>";
  
  mysqli_close($con);
?>
</table>