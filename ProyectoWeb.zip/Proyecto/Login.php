
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link href="Login_v12/Login_v12/css/util.css" rel="stylesheet" type="text/css">
<link href="Login_v12/Login_v12/css/main.css" rel="stylesheet" type="text/css">
<link href="Login_v12/Login_v12/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="Login_v12/Login_v12/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="Login_v12/Login_v12/vendor/animate/animate.css" rel="stylesheet" type="text/css">
<link href="Login_v12/Login_v12/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" type="text/css">
<link href="Login_v12/Login_v12/vendor/select2/select2.min.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="apDiv1" class="container-login100" style="background-image: url('Login_v12/Login_v12/images/img-01.jpg');">
<div class="login100-form-avatar">
						<img src="Login_v12/Login_v12/images/logo.jpeg" alt="AVATAR">
					</div>
					<span class="login100-form-title p-t-20 p-b-45">
						Bienvenido
					</span>
                    <div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
                    <form id="form1" name="form1" method="post" action="validar.php">
                    <center><table width="290" border="0"></center>
                    <tr>
                    <center><td><label for="cclave"></label></center>
                    <input type="text" name="usuario" id="textfield2" placeholder="Username" class="input100" data-validate = "Username is required"/></td></center>
                    </tr>
                    <tr>
                    <center><td><label for="textfield3"></label></center>
                    <input type="password" name="clave" id="textfield3" placeholder="Password" class="input100" data-validate = "Username is required"/></td></center>
                    </tr>
                    <tr>
                    <center><td><input type="submit" name="login" id="button" value="login" class="login100-form-btn"/></td></center>
                    <td>&nbsp;</td>
                    </tr>
                    </table>
                    </form>
                    </div>
            
            <div class="text-center w-full p-t-25 p-b-230">
						<a href="NoPass.php" class="txt1">
							Olvido usuario o contraseña?
						</a>
					</div>

					<div class="text-center w-full">
						<a class="txt1" href="Index.php">
							Volver
							<i class="fa fa-long-arrow-right"></i>						
						</a>
					</div>
				</form>
            </div>
    <script src="Login_v12/Login_v12/vendor/jquery/jquery-3.2.1.min.js"></script>
    <script src="Login_v12/Login_v12/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="Login_v12/Login_v12/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="Login_v12/Login_v12/vendor/select2/select2.min.js"></script>
    <script src="Login_v12/Login_v12/js/main.js"></script>


    
</body>
</html>
