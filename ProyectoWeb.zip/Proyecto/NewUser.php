<?php
                            session_start();
                            if (!isset($_SESSION['usuario'])) {
                            header("Location: Login.php");
                            }
                            $clave_ses = $_SESSION['usuario'];
                            ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V13</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="Login_v13/Login_v13/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/css/util.css">
	<link rel="stylesheet" type="text/css" href="Login_v13/Login_v13/css/main.css">
<!--===============================================================================================-->
</head>
<body style="background-color: #999999;">
	
	<div class="limiter">
		<div class="container-login100">
			<div class="login100-more" style="background-image: url('Login_v13/Login_v13/images/bg-01.jpg');"></div>

			<div class="wrap-login100 p-l-50 p-r-50 p-t-72 p-b-50">
				<form class="login100-form validate-form" method="submit" action="insertar.php">
					<span class="login100-form-title p-b-59">
						Nuevo Usuario
					</span>
					<left><table width="290" border="1"></table></left>
    	 <br>
                <center>Identificacion:<input type="text" id="id" name="cid" ></center>        
                <br>
                <br>
            <center> Nombres: <input type="text" id="nombres" name="cnomb"></center> 
                <br>
                <br>
            <center> Apellidos: <input type="text" id="apellido" name="cape"></center> 
                <br>
                <br>
            <center>Usuario: <input type="text" id="usuario" name="usuario"></center> 
                <br>
                <br>
            <center>Clave: <input type="password" id="direccion" name="cclave"></center> 
                <br>
				<br>
			<center>Cod.Empresarial: <input type="text" id="perfil" name="cod"></center> 
                <br>
                <br>
    <center>
      Tipo:
      <input type="radio" name="radio" id="administrador" value="administrador">
      <label for="administrador">Administrador</label>
      <input type="radio" name="radio" id="usuario" value="usuario">
      <label for="usuario">Usuario</label>
      <br>
                <br>
            </center>
    <center>
	<input type="submit" id="enviar" name="guardar" value="Guardar"></center>
	<a href="PrincipalUser.php" class="dis-block txt3 hov1 p-r-30 p-t-10 p-b-10 p-l-30">
							Volver
							<i class="fa fa-long-arrow-right m-l-5"></i>
						</a>
				</form>
			</div>
		</div>
	</div>
	
<!--===============================================================================================-->
	<script src="Login_v13/Login_v13/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v13/Login_v13/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v13/Login_v13/vendor/bootstrap/js/popper.js"></script>
	<script src="Login_v13/Login_v13/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v13/Login_v13/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v13/Login_v13/vendor/daterangepicker/moment.min.js"></script>
	<script src="Login_v13/Login_v13/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="Login_v13/Login_v13/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="Login_v13/Login_v13/js/main.js"></script>

</body>
</html>