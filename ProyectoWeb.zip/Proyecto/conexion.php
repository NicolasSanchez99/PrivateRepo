<?php
$host = "localhost";
$usuario = "root";
$clave = "";
$bd = "db_semi";
?>