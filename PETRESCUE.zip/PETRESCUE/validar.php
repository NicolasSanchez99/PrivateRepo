<?php
include_once('Conexion.php');

//1. Crear conexión a la Base de Datos
$con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
mysqli_set_charset($con,"utf8");
 $pamd=1; //Perfil Administrador
 $pcli=2; //Perfil Cliente
 $pexc=3; //Perfil baneado
 
if (isset($_POST['login'])) {
 //Recoger datos Variables de Usuario
 $usuario = $_POST['usuario'];
 $pass = $_POST['clave'];
  $consulta = "SELECT * from usuarios where usuario = '$usuario' and clave = '$pass'";
 $resultado = mysqli_query($con, $consulta);
while($fila = mysqli_fetch_assoc($resultado))
 {
$usu=$fila['usuario'];
$clav=$fila['clave'];
$perfil=$fila['perfiles_id_perfil'];
}


 //Valida Usuario y/Contraseña no coincidentes
 if (($usu != $usuario) | ($clav != $pass))
{
header("Location:INDEXX.php");
exit();
}

 //Valida Usuario y/Contraseña empty
 if (($usuario==null) | ($pass==null))
{
header("Location:INDEXX.php");
exit();
}

 //Valida perfil baneado
 if ($perfil==$pexc)
{
header("Location:INDEXX.php");
exit();
}

 //Valida perfil del Administrador
 if ($perfil==$pamd)
{
session_start();
$_SESSION['usuario'] = $usuario;
header("Location:home%20(2).php");
}


//Valida perfil Cliente
else if($perfil==$pcli)
{
session_start();
$_SESSION['usuario'] = $usuario;
header("Location:home%20(2).php");
}


//Valida perfil SperAdministrador
else if($perfil==$psadmon)
{
session_start();
$_SESSION['usuario'] = $usuario;
header("Location:PrincipalUser.php");
}
else
 {
 header("Location: INDEXX.php");
 exit();
 }
}
mysqli_close($con);
?>