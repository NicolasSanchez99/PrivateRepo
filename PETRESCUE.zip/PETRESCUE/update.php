<?php
//1. Invocar conexión
include_once("conexion.php");
//2. Crear conexión a la Base de Datos
$con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
mysqli_set_charset($con,"utf8");

$vid = $_GET['cid'];
$vnombre = $_GET['cnomb'];
$vape = $_GET['cape'];
$vtel=$_GET['telefono'];
$vdir=$_GET['direccion'];
$vuser = $_GET['usuario'];
$vclve = $_GET['cclave'];
$vperfil = $_GET['perfil'];
    $inserta = " UPDATE usuarios SET nombres=' $vnombre',apellidos= '$vape',telefono= '$vtel',direccion= '$vdir',usuario= '$vuser', clave= '$vclve', perfiles_id_perfil='$vperfil' WHERE idususarios=$vid;";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
mysqli_close($con);
?>