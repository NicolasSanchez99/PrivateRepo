<?php
//1. Invocar conexión
include_once("Conexion.php");
//2. Crear conexión a la Base de Datos
$con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
mysqli_set_charset($con,"utf8");


$vcc = $_GET['cc'];
$vtipo = $_GET['radio'];

$select = "SELECT idususarios FROM $bd.usuarios WHERE  usuario= $vcc;";
    $resultadoS = mysqli_query($con,$select);
    echo json_encode ($resultadoS);


if($vtipo == 'Alimentos'){
    $inserta = "INSERT INTO $bd.donaciones (`iddonaciones`, `tipo`, `usuarios_cedula`) VALUES (NULL,'Alimentos','$vcc');";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
}elseif($vtipo == 'Medicina'){
    $inserta = "INSERT INTO $bd.donaciones (`iddonaciones`, `tipo`, `usuarios_cedula`) VALUES (NULL,'Medicina','$vcc');";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
}elseif($vtipo == 'Juguetes'){
    $inserta = "INSERT INTO $bd.donaciones (`iddonaciones`, `tipo`, `usuarios_cedula`) VALUES (NULL,'Juguetes','$vcc');";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
}elseif($vtipo == 'Dinero'){
    $inserta = "INSERT INTO $bd.donaciones (`iddonaciones`, `tipo`, `usuarios_cedula`) VALUES (NULL,'Dinero','$vcc');";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
}elseif($vtipo == 'Premios'){
    $inserta = "INSERT INTO $bd.donaciones (`iddonaciones`, `tipo`, `usuarios_cedula`) VALUES (NULL,'Premios','$vcc');";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
}

mysqli_close($con);
?>