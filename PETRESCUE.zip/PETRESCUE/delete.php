<?php
include_once("Conexion.php");
//1. Crear conexión a la Base de Datos
$con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
mysqli_set_charset($con,"utf8");
//2. Tomar los campos provenientes de la tabla
$id=$_GET["cid"];
$consulta="DELETE FROM $bd.usuarios where idususarios='$id'";
$resultado = mysqli_query($con, $consulta);
header("Location:home%20(2).php");
mysqli_close($con);

?>