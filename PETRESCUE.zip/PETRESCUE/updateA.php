<?php
//1. Invocar conexión
include_once("conexion.php");
//2. Crear conexión a la Base de Datos
$con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
mysqli_set_charset($con,"utf8");

$vId = $_GET['cid'];
$vNom = $_GET['cnomb'];
$vRaz = $_GET['craz'];
$vEdad = $_GET['cedad'];
$vUser = $_GET['cuser'];
    $inserta = " UPDATE $bd.animales SET nombre = '$vNom', raza = '$vRaz', edad = '$vEdad', usuarios_cedula = '$vUser' WHERE idanimales = $vId;";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
mysqli_close($con);
?>