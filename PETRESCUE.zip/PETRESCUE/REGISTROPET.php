<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registro</title>
<style type="text/css">
body {
    background-color: #272727;
    background-image: url(images/Fondoo.jpg);
    text-align: center;
    font-family: Impact, Haettenschweiler, "Franklin Gothic Bold", "Arial Black", sans-serif;
}
</style>
</head>

<body>
<form id="form1" method="submit" action="insertar.php">
  <h1>&nbsp;</h1>
 <h1><strong><a href="INDEXX.php"><img src="images/volver.png" alt="" width="50" height="50" title="Volver" align="top"/></a></strong></h1>
  <blockquote>
    <blockquote>
      <blockquote>
        <h1><strong style="text-align: center; font-family: Impact, Haettenschweiler, 'Franklin Gothic Bold', 'Arial Black', sans-serif; font-size: 50px;">REGISTRO</strong> </h1>
      </blockquote>
    </blockquote>
  </blockquote>
  <p>
  <center>Identificacion:<input type="text" id="id" name="cid" ></center>        
                <br>
                <br>
            <center> Nombres: <input type="text" id="nombres" name="cnomb"></center> 
                <br>
                <br>
            <center> Apellidos: <input type="text" id="apellido" name="cape"></center> 
                <br>
                <br>
            <center> telefono: <input type="text" id="telefono" name="ctel"></center> 
                <br>
                <br>
            <center> direccion: <input type="text" id="direccion" name="cdir"></center> 
                <br>
                <br>
            <center>Usuario: <input type="text" id="usuario" name="cusu"></center> 
                <br>
                <br>
            <center>Clave: <input type="password" id="direccion" name="cclave"></center> 
                <br>
				        <br>
                <center>
      Tipo:
      <input type="radio" name="radio" id="administrador" value="administrador">
      <label for="administrador">Administrador</label>
      <input type="radio" name="radio" id="usuario" value="usuario">
      <label for="usuario">Usuario</label>
      <br>
                <br>
            </center>
                <p>
    <span style="text-align: center">
    <input type="submit" name="submit" id="submit" value="ENVIAR">
    </span><span style="text-align: center"> </span></p>
  <p>&nbsp;</p>
</form>
</body>
</html>
