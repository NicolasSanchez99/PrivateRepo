<?php
//1. Invocar conexión
include_once("Conexion.php");
//2. Crear conexión a la Base de Datos
$con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
mysqli_set_charset($con,"utf8");

$vNom = $_GET['cnomb'];
$vRaz = $_GET['craz'];
$vEdad = $_GET['cedad'];
$vUser = $_GET['cuser'];
    $inserta = "INSERT INTO $bd.animales (`idanimales`, `nombre`, `raza`, `edad`, `usuarios_cedula`) VALUES (NULL, '$vNom ', '$vRaz', '$vEdad','$vUser')";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
mysqli_close($con);
?>