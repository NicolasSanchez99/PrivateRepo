<?php
session_start();
if (!isset($_SESSION['usuario'])) {
     header("Location: home%20(2).php");
}
$clave_ses = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html lang="en">

<head>

     <title>Soft Landing Page by Tooplate</title>
     <!--

    Template 2106 Soft Landing

	http://www.tooplate.com/view/2106-soft-landing

    -->
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="team" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="2106_soft_landing/css/bootstrap.min.css">
     <link rel="stylesheet" href="2106_soft_landing/css/owl.carousel.css">
     <link rel="stylesheet" href="2106_soft_landing/css/owl.theme.default.min.css">
     <link rel="stylesheet" href="2106_soft_landing/css/font-awesome.min.css">
     <link rel="stylesheet" href="2106_soft_landing/css/Tablas.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="2106_soft_landing/css/tooplate-style.css">

</head>

<body>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>

          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="home%20(2).php" class="navbar-brand">Home</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                         <?php
                         include_once("conexion.php");
                         //1. Crear conexión a la Base de Datos
                         $con = mysqli_connect($host, $usuario, $clave, $bd) or die('Fallo la conexion');
                         mysqli_set_charset($con, "utf8");
                         //2. Tomar los campos provenientes de la tabla
                         $consulta = "SELECT $bd.usuarios.nombres AS nombre, $bd.usuarios.apellidos AS apellido,
                            $bd.actividades.nom_actividad AS actividad, $bd.actividades.id_actividades AS idAct,
                            $bd.actividades.enlace AS enlace FROM $bd.usuarios,$bd.actividades,$bd.perfiles,$bd.gestactividad
                            WHERE $bd.gestactividad.perfiles_id_perfil = $bd.perfiles.id_perfil AND $bd.gestactividad.actividades_id_actividades =
                            $bd.actividades.id_actividades AND $bd.perfiles.id_perfil = $bd.usuarios.perfiles_id_perfil AND $bd.usuarios.usuario
                            = '$clave_ses'";
                         $resultado = mysqli_query($con, $consulta);
                         while ($mostrar = mysqli_fetch_array($resultado)) {
                         ?>
                              <tr>
                                   <li align="center"><?php echo '<a href="' . $mostrar['enlace'] . '" ">' . $mostrar['actividad'] . '</a>'; ?></li>
                              </tr>
                         <?php
                         }
                         mysqli_close($con);
                         ?>

                         <?php
                         $con = mysqli_connect($host, $usuario, $clave, $bd) or die('Fallo la conexion');
                         mysqli_set_charset($con, "utf8");
                         $consulta = "SELECT nombres from usuarios where usuario = '$clave_ses' ";
                         $resultado = mysqli_query($con, $consulta);
                         while ($fila = mysqli_fetch_assoc($resultado)) {
                              $nom = $fila['nombres'];
                         }
                         $nom_usu = $nom . " ";
                         //$documento = $docu;
                         ?>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="Index.html"><span><?php echo $nom_usu; ?></span></a></li>
                    </ul>
               </div>

          </div>
     </section>

     <!-- Ventas -->
     <section id="feature" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h1>Funciones</h1>
                         </div>
                    </div>

                    <div class="col-md-6 col-sm-6">
                         <ul class="nav nav-tabs" role="tablist">
                              <li class="active"><a href="#tab01" aria-controls="tab01" role="tab" data-toggle="tab">
                                        Agregar</a></li>
                              <li><a href="#tab02" aria-controls="tab02" role="tab" data-toggle="tab">Eliminar</a></li>
                              <li><a href="#tab03" aria-controls="tab03" role="tab" data-toggle="tab">Modificar</a></li>
                              <li><a href="#tab04" aria-controls="tab04" role="tab" data-toggle="tab">Listar</a></li>
                         </ul>

                         <div class="tab-content">
                              <div class="tab-pane active" id="tab01" role="tabpanel">

                                   <form class="login100-form validate-form" method="submit" action="insertA.php">
                                        <span class="login100-form-title p-b-59">
                                             Nuevo Animal
                                        </span>
                                        <left>
                                             <table width="290" border="1"></table>
                                        </left>
                                        <br>
                                        <br>
                                        <center> Nombres: <input type="text" id="nombres" name="cnomb"></center>
                                        <br>
                                        <br>
                                        <center> Raza: <input type="text" id="apellido" name="craz"></center>
                                        <br>
                                        <br>
                                        <center> Edad: <input type="text" id="telefono" name="cedad"></center>
                                        <br>
                                        <br>
                                        <center> Id_usuario: <input type="text" id="direccion" name="cuser"></center>
                                        <br>
                                        <br>
                                        <center>
                                             <input type="submit" id="enviar" name="guardar" value="Guardar">
                                        </center>
                                        <a href="home%20(2).php" class="dis-block txt3 hov1 p-r-30 p-t-10 p-b-10 p-l-30">
                                             Volver
                                             <i class="fa fa-long-arrow-right m-l-5"></i>
                                        </a>
                                   </form>
                              </div>


                              <div class="tab-pane" id="tab02" role="tabpanel">
                                   <div class="tab-pane-item">
                                        <form id="contenedor-eliminarActividad" method="submit" action="deleteA.php">
                                             Perfil: <input type="text" id="nombres" name="cid">
                                             <br>
                                             <br>
                                             <input class="botonEliminar" type="submit" id="enviar" name="guardar" value="Eliminar">
                                        </form>
                                        <a href="home%20(2).php" class="dis-block txt3 hov1 p-r-30 p-t-10 p-b-10 p-l-30">
                                             Volver
                                             <i class="fa fa-long-arrow-right m-l-5"></i>
                                        </a>
                                   </div>

                              </div>

                              <div class="tab-pane" id="tab03" role="tabpanel">
                                   <div class="tab-pane-item">
                                        <h1>Modificacion</h1>
                                        <br>
                                        <br>
                                        <form method="submit" action="updateA.php">
                                             <table>
                                                  <tr>
                                                       <td> id</td>
                                                       <td><input type="text" name="cid" value=""></td>
                                                  <tr>
                                                  <tr>
                                                       <td>nuevo nombre</td>
                                                       <td><input type="text" name="cnomb" value=""></td>
                                                  </tr>
                                                  <tr>
                                                       <td>nuevo raza</td>
                                                       <td><input type="text" name="craz" value=""></td>
                                                  </tr>
                                                  <tr>
                                                       <td>nuevo edad</td>
                                                       <td><input type="text" name="cedad" value=""></td>
                                                  </tr>
                                                  <tr>
                                                       <td>nuevo dueño</td>
                                                       <td><input type="text" name="cuser" value=""></td>
                                                  </tr>
                                                  <tr>
                                                       <!-- <input type="hidden" name="oculto"> -->
                                                       <td colspan="2"><input type="submit" value="EDITAR"></td>
                                                  </tr>


                                             </table>
                                        </form>
                                        <a href="home%20(2).php" class="dis-block txt3 hov1 p-r-30 p-t-10 p-b-10 p-l-30">
                                             Volver
                                             <i class="fa fa-long-arrow-right m-l-5"></i>
                                        </a>
                                   </div>

                              </div>

                              <div class="tab-pane" id="tab04" role="tabpanel">
                                   <div class="container">
                                        <style>
                                             table {
                                                  table-layout: auto;
                                                  width: 500px;

                                             }
                                        </style>
                                        <center>
                                             <table border="1" cellspacing=2 cellpadding=2 style="font-size: 2em">
                                                  <tr>
                                                       <td>
                                                            <font face="verdana"><b>ID</b></font>
                                                       </td>
                                                       <td>
                                                            <font face="verdana"><b>NOMBRE</b></font>
                                                       </td>
                                                       <td>
                                                            <font face="verdana"><b>RAZA</b></font>
                                                       </td>
                                                       <td>
                                                            <font face="verdana"><b>EDAD</b></font>
                                                       </td>
                                                       <td>
                                                            <font face="verdana"><b>DUEÑO</b></font>
                                                       </td>
                                                  </tr>

                                                  <?php
                                                  include_once("conexion.php");
                                                  $con = new mysqli($host, $usuario, $clave, $bd) or die('Fallo la conexion');
                                                  $result = $con->query("SELECT * FROM $bd.animales");
                                                  //$numero = 0;
                                                  while ($row = mysqli_fetch_array($result)) {
                                                       echo "<tr><td width=\"5%\"><font face=\"verdana\">" .
                                                            $row["idanimales"] . "</font></td>";
                                                       echo "<td width=\"10%\"><font face=\"verdana\">" .
                                                            $row["nombre"] . "</font></td>";
                                                       echo "<td width=\"10%\"><font face=\"verdana\">" .
                                                            $row["raza"] . "</font></td>";
                                                       echo "<td width=\"10%\"><font face=\"verdana\">" .
                                                            $row["edad"] . "</font></td>";
                                                       echo "<td width=\"10%\"><font face=\"verdana\">" .
                                                            $row["usuarios_cedula"] . "</font></td></tr>";
                                                       //$numero++;
                                                  }
                                                  //echo "<tr><td colspan=\"10\"><font face=\"verdana\"><b>Número: " . $numero . 
                                                  //"</b></font></td></tr>";

                                                  mysqli_close($con);
                                                  ?>
                                             </table>
                                        </center>
                                   </div>

                              </div>

                         </div>
     </section>







     <!-- FOOTER -->
     <footer id="footer" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="copyright-text col-md-12 col-sm-12">
                         <div class="col-md-6 col-sm-6">
                              <p>Copyright &copy; PET RESCUE </p>
                         </div>

                         <div class="col-md-6 col-sm-6">
                              <ul class="social-icon">
                                   <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="#" class="fa fa-twitter"></a></li>
                                   <li><a href="#" class="fa fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>

               </div>
          </div>
     </footer>

     <!-- SCRIPTS -->
     <script src="2106_soft_landing/js/jquery.js"></script>
     <script src="2106_soft_landing/js/bootstrap.min.js"></script>
     <script src="2106_soft_landing/js/jquery.stellar.min.js"></script>
     <script src="2106_soft_landing/js/owl.carousel.min.js"></script>
     <script src="2106_soft_landing/js/smoothscroll.js"></script>
     <script src="2106_soft_landing/js/custom.js"></script>

</body>

</html>