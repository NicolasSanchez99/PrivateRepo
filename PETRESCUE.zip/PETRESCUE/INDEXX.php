<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>D-pot</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">	
<!-- bootstrap css -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<!-- style css -->
<link rel="stylesheet" type="text/css" href="css/style.css">
<!-- Responsive-->
<link rel="stylesheet" href="css/responsive.css">
<!-- fevicon -->
<link rel="icon" href="images/fevicon.png" type="image/gif" />
<!-- Scrollbar Custom CSS -->
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
<!-- Tweaks for older IEs-->
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
<!-- owl stylesheets --> 
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
<style type="text/css">
.header_section .banner_main .container .ram .row .col-sm-12 .banner_bt .read_bt {
    font-family: Constantia, Lucida Bright, DejaVu Serif, Georgia, serif;
}
</style>
</head>
<body>
	<!-- section banner start -->
<div class="header_section">
		<div class="container-fluid">
			<div class="row">
			<div class="col-md-4">
					<div><a href="index.php"><img src="images/Logo1.PNG"></a></div>
				</div>
				<div class="col-md-8">
					<div class="menu_text">
						<ul>
						  <li class="last"><strong><a href="INICIO SESION PET.php">Log</a></strong> <a href="INICIO SESION PET.php"><strong>in</strong> </a><strong>/</strong></li>
							<li class="active">
							 <div id="myNav" class="overlay">
                                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                             <div class="overlay-content">
                             	<a href="home (2).php">Home</a>
                                <a href="Adopciones.php">Adopciones</a>
                                <a href="Donaciones.php">Donaciones De Insumos</a>
								<a href="Formularios.php">Formularios</a>
                                <a href="contacto.php">Contacto</a>
								 
                              </div>
                            </div>
                             
                            </div>	
                            </li>
				  </ul>
			  </div>
			</div>
		</div>
		<div class="banner_main">
			<div class="container">
				<div class="ram">
					<div class="row">
						<div class="col-sm-12">
						    <h1 class="taital">
						      <ol>
						        <li>¡Los animalitos necesitan tu ayuda!</li>
					          </ol>
						    </h1>
						    <p class="consectetur_text"> puedes ayudar donando insumos</p>
						    <div class="banner_bt">
						    	<button class="read_bt">Leer Más</button>
						    </div>
					    </div>
				    </div>
				</div>
				<div class="box">
					<h1 class="numbar_text">01</h1>
				</div>
			</div>
		</div>
</div>
	<!-- section banner end -->
	<!-- section about start -->
	<div class="about_section">
		<div class="about_text">
			<div class="container">
			  <h1 class="about_taital_1"><strong><span style="color:#F70D1A;"> Acerca</span> De Nosotros </strong></h1>
			  <p class="magna_text"> Somos un equipo dispuesto a ayudar a animales que estan en condiciones vulnerables, nuestro objetivo es brindarles calidad de vida, una vida digna junto a una familia que le brinde cariño, respeto, protección y diversión, porque ellos merecen lo mejor!</p>
				<div class="about_bt">
					<button class="more_bt"> Leer Más </button>
				</div>
				<div class="about">
					<h1 class="numbar_text">02</h1>
				</div>
			</div>
		</div>
	</div>
	<!-- section about end -->
	<!-- section gallery start -->
    <div class="gallery_main layout_padding">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
    			  <h1 class="about_taital"><strong><font color="#F70D1A">Nuestros</font> Animales</strong></h1>
    			  <p class="sed_text"> A continuación podrás ver algunos de nuestros animales que se encuentran disponibles para adopción. </p>
				  <img src="images/Patacon.jpg"  height: 300px; width: 100%;>
    			</div>
    		</div>
			</div>
			<div class="col-sm-5">
						
                           
    				</div>
    			</div>
	            </div>
    		<div class="gallery_images">
    			<div class="row">
    				<div class="col-sm-5">
						<div class="gallery_blog">
                           <img src="../../../OneDrive - Universidad de San Buenaventura - Bogota/Pictures/GATO (2).jpg" style="max-width: 100%; width: 100%;">
                        <div class="overlay">
                            <div class="text"><strong>PuppyDogPetAnimal</strong></div>
                        </div>
					    </div>
    				</div>
    				<div class="col-sm-7">
						<div class="gallery_blog">
                           
                        <div class="overlay">
                            <div class="text"><strong>PuppyDogPetAnimal</strong></div>
                        </div>
					    </div>
						<div class="gallery_blog">
                           
                        <div class="overlay">
                            <div class="text"><strong>PuppyDogPetAnimal</strong></div>
                        </div>
					    </div>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
    <div class="gallery_section_2">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-8 col-lg-5 col-md-6">
    			  <h1 class="pet_taital"> ¡Adopta una mascota y se parte de algo maravilloso!</h1>
				  
    			
				<div class="box_3">
					<h1 class="numbar">03</h1>
				</div>
    			</div>
    			
				<div class="col-sm-4 col-md-1"><img src="images/king.jpg" width="375" height="300" alt=""/>	
<div class="dog_img"></div>
   			  </div>
    		</div>
    	</div>
    </div>
	<!-- section gallery end -->
	<!-- section get in touch start -->
    <div class="touch_section">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
				    <h1 class="get_taital"><strong><span style="color:#F70D1A;"> Contáctanos </span>  </strong></h1>
    			</div>
    		</div>
    		<div class="email_box">
                    <div class="input_main">
                       <div class="container">
                          <form action="/action_page.php">
                            <div class="form-group">
                              <input type="text" class="email-bt" placeholder="Nombre" name="Nombre">
                            </div>
                            <div class="form-group">
                              <input type="text" class="email-bt" placeholder="Número celular " name="Nombre">
                            </div>
                            <div class="form-group">
                              <input type="text" class="email-bt" placeholder="Correo" name="Correo">
                            </div>
                            
                            <div class="form-group">
                                <textarea class="massage-bt" placeholder="Mensaje" rows="5" id="comment" name="Mensaje"></textarea>
                            </div>
                          </form>   
                       </div> 
                       <div class="send_btn">
                        <button type="button" class="main_bt"><a href="#">Enviar</a></button>
                       </div>                   
                    </div>
    		</div>
    	</div>
    </div>
    <div class="touch_section_2">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
    			  <h1 class="our_texts"><strong>Nuestro</strong> <strong>Boletín</strong> <strong>Informativo</strong></h1>
    			  <div class="input-group mb-3">
                        <input class="email_bt" type="text" class="form-control" placeholder="Ingrese Su Correo">
                     <div class="input-group-append">
                        <button class="subscribe_bt" class="btn btn-primary" type="Suscribirse">Suscribirse</button>  
                     </div>
                    </div>
    			</div>
    		</div>
    	</div>
    </div>
    <!-- section get in touch end -->

	<!-- section footer start -->
    <div class="section_footer">
    	<div class="container">
    		<div class="mail_section">
    			<ul>
    				<li class="footer-logo"><img src="../../../OneDrive - Universidad de San Buenaventura - Bogota/Pictures/Logo1.PNG" width="345" height="152" alt=""/></li>
    				<li class="footer-logo"><img src="images/map-icon.png"><span class="map_text">Bogotá, Colombia </span></li>
    				<li class="footer-logo"><img src="images/call-icon.png"><span class="map_text">(+57) 3046015664 </span></li>
    				<li class="footer-logo"><img src="images/email-icon.png"><span class="map_text">macagomez103@gmail.com </span></li>
    			</ul>
    	    </div>
	            <div class="copyright">2021 All Rights Reserved. <a href="https://html.design">Free html Templates</a></div>
	        </div>
    	</div>
    </div>
	<!-- section footer end -->

    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <!-- javascript --> 
      <script src="js/owl.carousel.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
      $(document).ready(function(){
      $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         </script> 


   <script>
    function openNav() {
    document.getElementById("myNav").style.width = "100%";
    }

    function closeNav() {
   document.getElementById("myNav").style.width = "0%";
   }
</script>
     
</body>
</html>