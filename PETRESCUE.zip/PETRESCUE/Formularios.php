<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>D-pot</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">	
<!-- bootstrap css -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<!-- style css -->
<link rel="stylesheet" type="text/css" href="css/style.css">
<!-- Responsive-->
<link rel="stylesheet" href="css/responsive.css">
<!-- fevicon -->
<link rel="icon" href="images/fevicon.png" type="image/gif" />
<!-- Scrollbar Custom CSS -->
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
<!-- Tweaks for older IEs-->
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
<!-- owl stylesheets --> 
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
<style type="text/css">
body,td,th {
    font-family: "Josefin Sans", sans-serif;
    color: #FFF8F8;
    font-size: 25px;
}
body {
    background-image: url(images/Fondo5.pg.jpg);
    background-color: #000000;
}
.adopciones_section .about_text .container pre strong {
    font-family: Cambria, Hoefler Text, Liberation Serif, Times, Times New Roman, serif;
}
</style>
</head>
<body>
	<!-- section banner start -->
	<div class="header-main">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4">
					<div><a href="index.php"><img src="images/Logo1.PNG"></a></div>
				</div>
				<div class="col-md-8">
					<div class="menu_text">
						<ul>
							
							<li class="last"><img src="images/search-icon.png"></li>
							<li class="active">
							<div id="myNav" class="overlay">
                               <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                            <div class="overlay-content">
                               <a href="INDEXX.php">Home</a>
                               <a href="Adopciones.php">Adopciones</a>
                               <a href="Donaciones.php">Donaciones De Insumos</a>
								<a href="Formularios.php">Formularios</a>
                               <a href="contact.php">Contacto</a>
                            </div>
                            </div>
                            <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>
                           </div>	
                           </li>
						</ul>
					</div>
			</div>
		</div>
    </div>
	<!-- section get in touch start -->
<div class="Formulario_section">
  <div class="about_text">
    <div class="container">
      <p>
		    <h class="about_taital"></p>
      <p>
      <h1><strong><span style="font-size: 75px; color: #F70D1A"> ¡Llena Tu </span>   
        <span style=" font-size: 55px; color: #FFFFFF"></span> Formulario!
        
      </strong></h1>
      <strong>
      <p class="magna_text"> A continuación podrás descargar un formulario para seguir con tu proceso de adopción de un peludito!</p>
      </strong>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp; </p>
      <p>&nbsp;</p>
      <p><strong>        </strong>
      </p>
      <p><strong>
        </strong>
      </p>
      <p><img src="images/FormularioAdopcion.jpg" width="768" height="1024" alt=""/>
      </p>
</div>
  </div>
    </div>
  </div>
  <!-- section about end -->
	<!-- section footer start -->
    <div class="section_footer">
      <p>
      <div class="container">
   		  <div class="mail_section">
    			<ul>
    				<li class="footer-logo"><img src="images/Logo1.PNG" width="205" height="107"></li>
    				<li class="footer-logo"><img src="images/map-icon.png"><span class="map_text">Bogotá, Colombia</span></li>
    				<li class="footer-logo"><img src="images/call-icon.png"><span class="map_text">(+57) 3046015664</span></li>
    				<li class="footer-logo"><img src="images/email-icon.png"><span class="map_text">macagomez103@gmail.com</span></li>
    			</ul>
        </div> 
      </div>
	           <div class="copyright">2021 All Rights Reserved. <a href="https://html.design">Free html Templates</a></div>
</div>
    	</div>
    </div>
	<!-- section footer end -->



<!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <!-- javascript --> 
      <script src="js/owl.carousel.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
      $(document).ready(function(){
      $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         </script> 


   <script>
    function openNav() {
    document.getElementById("myNav").style.width = "100%";
    }

    function closeNav() {
   document.getElementById("myNav").style.width = "0%";
   }
</script>
</body>
</html>

	  
	  
	  
	  
	  
