<?php
                            session_start();
                            if (!isset($_SESSION['usuario'])) {
                            header("Location: Login.php");
                            }
                            $clave_ses = $_SESSION['usuario'];
                            ?>
<!DOCTYPE html>
<html lang="en">

<head>

     <title>Soft Landing Page by Tooplate</title>
     <!--

    Template 2106 Soft Landing

	http://www.tooplate.com/view/2106-soft-landing

    -->
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="team" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="2106_soft_landing/css/bootstrap.min.css">
     <link rel="stylesheet" href="2106_soft_landing/css/owl.carousel.css">
     <link rel="stylesheet" href="2106_soft_landing/css/owl.theme.default.min.css">
     <link rel="stylesheet" href="2106_soft_landing/css/font-awesome.min.css">
     <link rel="stylesheet" href="2106_soft_landing/css/Tablas.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="2106_soft_landing/css/tooplate-style.css">

     

</head>

<body >

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>

          </div>
     </section>

     <div class="col-md-4">
					<div><a href="index.php"><img src="images/Logo1.PNG"></a></div>
				</div>
     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="home%20(2).php" class="navbar-brand">Home</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                            <?php
                            include_once("conexion.php");
                            //1. Crear conexión a la Base de Datos
                            $con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
                            mysqli_set_charset($con,"utf8");
                            //2. Tomar los campos provenientes de la tabla
                            $consulta="SELECT $bd.usuarios.nombres AS nombre, $bd.usuarios.apellidos AS apellido,
                            $bd.actividades.nom_actividad AS actividad, $bd.actividades.id_actividades AS idAct,
                            $bd.actividades.enlace AS enlace FROM $bd.usuarios,$bd.actividades,$bd.perfiles,$bd.gestactividad
                            WHERE $bd.gestactividad.perfiles_id_perfil = $bd.perfiles.id_perfil AND $bd.gestactividad.actividades_id_actividades =
                            $bd.actividades.id_actividades AND $bd.perfiles.id_perfil = $bd.usuarios.perfiles_id_perfil AND $bd.usuarios.usuario
                            = '$clave_ses'";
                            $resultado = mysqli_query($con, $consulta);
                            while($mostrar = mysqli_fetch_array($resultado)){
                            ?>  
                                <tr>
                                <li align="center"><?php echo '<a href="'.$mostrar['enlace'].'" ">'.$mostrar['actividad'].'</a>';?></li>
                                </tr> 
                                <?php 
				                    }
				                      mysqli_close($con);  
			                      ?>

                              <?php
                              $con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
                              mysqli_set_charset($con,"utf8");
                              $consulta = "SELECT nombres from usuarios where usuario = '$clave_ses' ";
                              $resultado = mysqli_query($con, $consulta);
                              while($fila = mysqli_fetch_assoc($resultado))
                              {
                              $nom=$fila['nombres'];

                              }
                              $nom_usu = $nom." ";
                              //$documento = $docu;
                              ?>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="Index.html"><span><?php echo $nom_usu; ?></span></a></li>
                    </ul>
               </div>

          </div>
     </section>
     
     <!-- Ventas -->
     <section id="feature" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h1>Funciones</h1>
                         </div>
                    </div>

                    <div class="col-md-6 col-sm-6">
                         <ul class="nav nav-tabs" role="tablist">
                              <li class="active"><a href="#tab01" aria-controls="tab01" role="tab" data-toggle="tab">
                                        Agregar</a></li>
                              <li><a href="#tab02" aria-controls="tab02" role="tab" data-toggle="tab">Revocar</a></li>
                         </ul>

                         <div class="tab-content">
                              <div class="tab-pane active" id="tab01" role="tabpanel">
                                   <form id="Menu" method="submit" action="agregar-actividad.php">
                                   Id: <input type="number" id="cidGest" name="cidGest">
                                   <br>
                                   <br>
                                   Perfil: <input type="number" id="cidPerf" name="cidPerf">
                                   <br>
                                   <br>
                                   Id Actividad: <input type="number" id="cidAct" name="cidAct">
                                   <br>
                                   <br>
                                   <input class="boton" type="submit" id="enviar" name="guardar" value="Guardar">
                                   </form>
                              </div>


                              <div class="tab-pane" id="tab02" role="tabpanel">
                                   <div class="tab-pane-item">
                                   <form id="contenedor-eliminarActividad" method="submit" action="eliminar-actividad.php">
                                        Perfil: <input type="text" id="nombres" name="cidPer">
                                        <br>
                                        <br>
                                        Id Actividad: <input type="text" id="apellidos" name="cidAct">
                                        <br>
                                        <br>
                                   <input class="botonEliminar" type="submit" id="enviar" name="guardar" value="Eliminar">
                                   </form>
                              </div>
                    
               </div>
          </div>
     </section>





    

     <!-- FOOTER -->
     <footer id="footer" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="copyright-text col-md-12 col-sm-12">
                         <div class="col-md-6 col-sm-6">
                              <p>Copyright &copy; PET RESCUE </p>
                         </div>

                         <div class="col-md-6 col-sm-6">
                              <ul class="social-icon">
                                   <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="#" class="fa fa-twitter"></a></li>
                                   <li><a href="#" class="fa fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>

               </div>
          </div>
     </footer>

     <!-- SCRIPTS -->
     <script src="2106_soft_landing/js/jquery.js"></script>
     <script src="2106_soft_landing/js/bootstrap.min.js"></script>
     <script src="2106_soft_landing/js/jquery.stellar.min.js"></script>
     <script src="2106_soft_landing/js/owl.carousel.min.js"></script>
     <script src="2106_soft_landing/js/smoothscroll.js"></script>
     <script src="2106_soft_landing/js/custom.js"></script>

</body>

</html>