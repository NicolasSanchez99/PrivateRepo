<?php
//1. Invocar conexión
include_once("conexion.php");
//2. Crear conexión a la Base de Datos
$con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
mysqli_set_charset($con,"utf8");

$vidPerfil = $_GET['cidPer'];
$vidActiv = $_GET['cidAct'];
    $inserta = "DELETE FROM $bd.gestactividad WHERE $bd.gestactividad.perfiles_id_perfil = $vidPerfil and $bd.gestactividad.actividades_id_actividades = $vidActiv";
    $resultado = mysqli_query($con,$inserta);
    header("Location:home%20(2).php");
mysqli_close($con);
?>