<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Inicio De Sesión</title>
<style type="text/css">
body {
    background-color: #FFFFFF;
    background-image: url(images/Fondo.jpg);
    margin-left: 450px;
    margin-top: 50px;
    margin-right: 80px;
    text-align: center;
    color: #000000;
}
#form1 p label {
    font-family: Impact, Haettenschweiler, Franklin Gothic Bold, Arial Black, sans-serif;
}
#form1 table tbody tr th h1 strong {
    font-family: Impact, Haettenschweiler, Franklin Gothic Bold, Arial Black, sans-serif;
}
#form1 table tbody tr th h1 strong {
    font-family: Impact, Haettenschweiler, Franklin Gothic Bold, Arial Black, sans-serif;
    font-size: 46px;
    text-align: left;
}
#form1 table tbody tr th p span strong label {
    font-family: Cambria, Hoefler Text, Liberation Serif, Times, Times New Roman, serif;
}
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="validar.php">
<p>&nbsp;</p>
  <table width="427" height="349" border="0">
    <tbody>
      <tr>
        <th bgcolor="#FFFDFD" scope="col"><div>
          <h1><strong><a href="INDEXX.php"><img src="images/volver.png" alt="" width="50" height="50" title="Volver" align="top"/></a></strong></h1>
        </div>
          <h1><strong> INICIO DE SESIÓN</strong></h1>
          <p>&nbsp;</p>
          <form id="form1" name="form1" method="post" >
                    <center><table width="290" border="0"></center>
                    <tr>
                    <center><td><label for="cclave"></label></center>
                    <input type="text" name="usuario" id="textfield2" placeholder="USUARIO" class="input100" data-validate = "Username is required"/></td></center>
                    </tr>
                    <tr>
                    <center><td><label for="textfield3"></label></center>
                    <input type="password" name="clave" id="textfield3" placeholder="CONTRASEÑA" class="input100" data-validate = "Username is required"/></td></center>
                    </tr>
                    <tr>
                    <center><td><input type="submit" name="login" id="button" value="login" class="login100-form-btn"/></td></center>
                    <td>&nbsp;</td>
                    </tr>
                    </table>
                    </form>
  </th>
      </tr>
    </tbody>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</body>
</html>
