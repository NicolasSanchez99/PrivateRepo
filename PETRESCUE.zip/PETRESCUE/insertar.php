<?php
//1. Invocar conexión
include_once("conexion.php");
//2. Crear conexión a la Base de Datos
$con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
mysqli_set_charset($con,"utf8");

$vid = $_GET['cid'];
$vnombre = $_GET['cnomb'];
$vape = $_GET['cape'];
$vuser = $_GET['cusu'];
$vtel= $_GET['ctel'];
$vdir= $_GET['cdir'];
$vclve = $_GET['cclave'];
$vtipo = $_GET['radio'];
if($vtipo == 'administrador'){
    $inserta = "INSERT INTO $bd.usuarios (`idususarios`, `nombres`, `apellidos`, `telefono`, `direccion`, `clave`, `usuario`, `perfiles_id_perfil`) VALUES ('$vid','$vnombre','$vape','$vtel','$vdir','$vclve','$vuser','1');";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
}elseif($vtipo == 'usuario'){
    $inserta = "INSERT INTO $bd.usuarios (`idususarios`, `nombres`, `apellidos`, `telefono`, `direccion`, `clave`, `usuario`, `perfiles_id_perfil`) VALUES ('$vid','$vnombre','$vape','$vtel','$vdir','$vclve','$vuser','2');";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
}elseif($vtipo == 'excluido'){
    $inserta = "INSERT INTO $bd.usuarios (`idususarios`, `nombres`, `apellidos`, `telefono`, `direccion`, `clave`, `usuario`, `perfiles_id_perfil`) VALUES ('$vid','$vnombre','$vape','$vtel','$vdir','$vclve','$vuser','4');";
    $resultado = mysqli_query($con,$inserta);
    echo json_encode ($resultado);
    header("Location:home%20(2).php");
}

mysqli_close($con);
?>