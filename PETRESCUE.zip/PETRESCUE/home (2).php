<?php
                            session_start();
                            if (!isset($_SESSION['usuario'])) {
                            header("Location: INDEXX.php");
                            }
                            $clave_ses = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>D-pot</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">	
<!-- bootstrap css -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<!-- style css -->
<link rel="stylesheet" type="text/css" href="css/style.css">
<!-- Responsive-->
<link rel="stylesheet" href="css/responsive.css">
<!-- fevicon -->
<link rel="icon" href="images/fevicon.png" type="image/gif" />
<!-- Scrollbar Custom CSS -->
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
<!-- Tweaks for older IEs-->
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
<!-- owl stylesheets --> 
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">

</head>
<body>
	<!-- section banner start -->
	<div class="header_section">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4">
					<div><a href="index.php"><img src="images/Logo1.PNG"></a></div>
				</div>
				<div class="col-md-8">
					<div class="menu_text">
					
					<?php
							include_once("Conexion.php");
                              $con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
                              mysqli_set_charset($con,"utf8");
                              $consulta = "SELECT nombres from $bd.usuarios where usuario = '$clave_ses' ";
                              $resultado = mysqli_query($con, $consulta);
                              while($fila = mysqli_fetch_assoc($resultado))
                              {
                              	$nom=$fila['nombres'];
								
                              }
                              $nom_usu = $nom." ";
                              //$documento = $docu;
                              ?>
						<ul class="nav navbar-nav navbar-right">
						  <ul>
							<li><a href="Login.php"><span><?php echo $nom_usu; ?></span></a></li>
							<li><a href="CerrarSesion.php">LOG OUT</a> </li>
				  		</ul>
                         </ul>

					<?php
                            include_once("Conexion.php");
                            //1. Crear conexión a la Base de Datos
                            $con=mysqli_connect($host,$usuario,$clave,$bd) or die('Fallo la conexion');
                            mysqli_set_charset($con,"utf8");
                            //2. Tomar los campos provenientes de la tabla
                            $consulta="SELECT $bd.usuarios.nombres AS nombre, $bd.usuarios.apellidos AS apellido,
                            $bd.actividades.nom_actividad AS actividad, $bd.actividades.id_actividades AS idAct,
                            $bd.actividades.enlace AS enlace FROM $bd.usuarios,$bd.actividades,$bd.perfiles,$bd.gestactividad
                            WHERE $bd.gestactividad.perfiles_id_perfil = $bd.perfiles.id_perfil AND $bd.gestactividad.actividades_id_actividades =
                            $bd.actividades.id_actividades AND $bd.perfiles.id_perfil = $bd.usuarios.perfiles_id_perfil AND $bd.usuarios.usuario
                            = '$clave_ses'";
                            $resultado = mysqli_query($con, $consulta);
                            while($mostrar = mysqli_fetch_array($resultado)){
                            ?>  
                                <tr>
                                <li align="center"><?php echo '<a href="'.$mostrar['enlace'].'" ">'.$mostrar['actividad'].'</a>';?></li>
                                </tr> 
                                <?php 
				                    }
				                      mysqli_close($con);  
			                    ?>
			  </div>
			</div>
		</div>
		<div class="banner_main">
			<div class="container">
				<div class="ram">
					<div class="row">
					    <div class="col-sm-12">
						    <h1 class="taital">¡Los animalitos necesitan tu ayuda!</h1>
						    <p class="consectetur_text">puedes ayudar donando insumos</p>
						    <div class="banner_bt">
						    	
						    </div>
					    </div>
				    </div>
				</div>
				<div class="box">
					<h1 class="numbar_text">01</h1>
				</div>
			</div>
		</div>
	</div>
	<!-- section banner end -->
	<!-- section about start -->
	<div class="about_section">
		<div class="about_text">
			<div class="container">
				<h1 class="about_taital_1"><strong><span style="color: #F70D1A;">Acerca De</span> Nosotros</strong></h1>
				<p class="magna_text"> Somos un equipo dispuesto a ayudar a animales que estan en condiciones vulnerables, nuestro objetivo es brindarles calidad de vida, una vida digna junto a una familia que le brinde cariño, respeto, protección y diversión, porque ellos merecen lo mejor!</p>
				<div class="about_bt">
				</div>
				<div class="about">
					<h1 class="numbar_text">02</h1>
				</div>
			</div>
		</div>
	</div>
	<!-- section about end -->
	<!-- section gallery start -->
    <div class="gallery_main layout_padding">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
    				<h1 class="about_taital"><strong><span style="color: #F70D1A;">Nuestros </span> Animales</strong></h1>
				    <p class="sed_text"> A continuación podrás ver algunos de nuestros animales que se encuentran disponibles para adopción.</p>
					<img src="images/Patacon.jpg" >
    			</div>
    		</div>
    		
    		
    	</div>
    </div>
    <div class="gallery_section_2">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-8 col-lg-5 col-md-6">
    			  <h1 class="pet_taital"> ¡Adopta una mascota y se parte de algo maravilloso!</h1>
				  
    			
				<div class="box_3">
					<h1 class="numbar">03</h1>
				</div>
    			</div>
    			<div class="col-sm-4 col-md-1"><img src="images/king.jpg" width="375" height="300" alt=""/>	
<div class="dog_img"></div>
   			  </div>
    		</div>
    	</div>
    </div>
	<!-- section gallery end -->
	<!-- section get in touch start -->
    <div class="touch_section">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
				    <h1 class="get_taital"><strong><span style="color:#F70D1A ;">Contáctanos</span> </strong></h1>
    			</div>
    		</div>
    		<div class="email_box">
                    <div class="input_main">
                       <div class="container">
                          <form action="/action_page.php">
                            <div class="form-group">
                              <input type="text" class="email-bt" placeholder="Nombre" name="name">
                            </div>
                            <div class="form-group">
                              <input type="text" class="email-bt" placeholder="Número de teléfono" name="Name">
                            </div>
                            <div class="form-group">
                              <input type="text" class="email-bt" placeholder="Correo" name="Email">
                            </div>
                            
                            <div class="form-group">
                                <textarea class="massage-bt" placeholder="Comentario" rows="5" id="Comentario" name="Massage"></textarea>
                            </div>
                          </form>   
                       </div> 
                       <div class="send_btn">
                        <button type="button" class="main_bt"><a href="#">Enviar</a></button>
                       </div>                   
                    </div>
    		</div>
    	</div>
    </div>
    <div class="touch_section_2">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
    				<h1 class="our_texts">Nuestro Boletín Informativo</h1>
    				<div class="input-group mb-3">
                        <input class="email_bt" type="text" class="form-control" placeholder="Ingrese Su Correo">
                     <div class="input-group-append">
                        <button class="subscribe_bt" class="btn btn-primary" type="Subscribe">Suscribirse</button>  
                     </div>
                    </div>
    			</div>
    		</div>
    	</div>
    </div>
    <!-- section get in touch end -->

	<!-- section footer start -->
    <div class="section_footer">
    	<div class="container">
    		<div class="mail_section">
    			<ul>
    				<li class="footer-logo"><img src="images/Logo1.PNG" width="345" height="152" alt=""/></li>
    				<li class="footer-logo"><img src="images/map-icon.png"><span class="map_text">Bogotá, Colombia</span></li>
    				<li class="footer-logo"><img src="images/call-icon.png"><span class="map_text">(+57) 3046015664</span></li>
    				<li class="footer-logo"><img src="images/email-icon.png"><span class="map_text">macagomez103@gmail.com</span></li>
    			</ul>
    	    </div> 
    	    <div class="footer_section_2">
		        <div class="row">
    		        <div class="col-sm-6 col-md-6 col-lg-3">
    		        	
   		          </div>

    		        </div>
    						</div>
    					</div>
    				</div>
    			</div>
    			
	        				    </ul>
	        			    </div>
	        		    </div>
	        	    </div>
	            </div>
	            <div class="copyright">2021 All Rights Reserved. <a href="https://html.design">Free html Templates</a></div>
	        </div>
    	</div>
    </div>
	<!-- section footer end -->

    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <!-- javascript --> 
      <script src="js/owl.carousel.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
      $(document).ready(function(){
      $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         </script> 


   <script>
    function openNav() {
    document.getElementById("myNav").style.width = "100%";
    }

    function closeNav() {
   document.getElementById("myNav").style.width = "0%";
   }
</script>
     
</body>
</html>
