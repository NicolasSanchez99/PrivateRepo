/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solid;

/**
 *
 * @author Usuario
 */
public class main extends S_Agregar{
    public static void main(String[] args) {
        S_Agregar a=new S_Agregar();
        a.add(new O_Blackberry());
        a.add(new O_leman() );
        L_Verduras l=new L_Verduras(0, 0, "e", "er");
        Fruta f=new Fruta(0, 0, "e", l);
        f.getSabor().paga();
    }

//    private static void print(aBS_fruit[] arrayf) {
//        for (aBS_fruit bS_fruit : arrayf) {
//            System.out.println( bS_fruit.fruta());
//        }
//    }
}
