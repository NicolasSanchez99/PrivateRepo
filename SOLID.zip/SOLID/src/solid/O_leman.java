/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solid;

/**
 *
 * @author Usuario
 */
public class O_leman extends aBS_fruit implements I_InterFru{

    @Override
    double weight() {
       return 89889;
    }

    @Override
    double price() {
        return 66.5;
    }

    @Override
    public String getName() {
        return "mora";
    }

    @Override
    public boolean nacional() {
       return false;
    }


    
}
