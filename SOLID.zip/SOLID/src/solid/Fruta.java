/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solid;

/**
 *
 * @author Usuario
 */
public class Fruta extends Productos{
    private L_Verduras sabor;
    public Fruta(double peso, double precio, String serial,L_Verduras sabor) {
        super(peso, precio, serial);
        this.sabor=sabor;
        
    }

    public L_Verduras getSabor() {
        return sabor;
    }

    public void setSabor(L_Verduras sabor) {
        this.sabor = sabor;
    }
    
}
