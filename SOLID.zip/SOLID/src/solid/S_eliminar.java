/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solid;

/**
 *
 * @author Usuario
 */
public class S_eliminar extends S_Agregar{
        void eliminar(Object f){
        Fruit.remove(f);
        System.out.println(Fruit.size());
    }
}
