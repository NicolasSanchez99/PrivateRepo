/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solid;

/**
 *
 * @author Usuario
 */
public class O_Blackberry extends aBS_fruit implements I_InterFru{


    @Override
    double weight() {
        return 125;
    }

    @Override
    double price() {
        return 15478;
    }

    @Override
    public String getName() {
        return "mora";
    }

    @Override
    public boolean nacional() {
        return true;
    }







  
    
}
