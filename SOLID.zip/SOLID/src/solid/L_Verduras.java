/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solid;

/**
 *
 * @author Usuario
 */
public class L_Verduras extends Productos{

    public L_Verduras(double precio,double peso,String serial,String reg){
        super(peso, precio,serial);
        this.reg=reg;
    }
    private String reg;

    public String getReg() {
        return reg;
    }

    public void setReg(String reg) {
        this.reg = reg;
    }
     public void paga()
     {
         System.out.println("serial:"+getSerial()+"region"+reg); 
     }    
}
