INSERT sars_db.proveedor select distinct provider_location_guid as 'ubicacion',
loc_phone as 'telefono',
loc_name as 'nombre', 
loc_admin_state 'estado',
web_address as 'pagina_web',
loc_admin_city as 'ciudad',
loc_admin_street1 as 'direccion',
loc_admin_street2 as 'complejo',
loc_admin_zip as 'codigo_postal'
from csv.primera_tabla WHERE provider_location_guid <> ' ' AND loc_phone <> ' ' AND loc_name <> ' ' AND loc_admin_state <> ' ' 
AND web_address <> ' ' AND loc_admin_city <> ' ' AND loc_admin_street1 <> ' ' AND  loc_admin_street2 <> ' ' AND loc_admin_zip <> ' ' ;



select provider_location_guid as 'ubicacion',
loc_phone as 'telefono',
loc_name as 'nombre', 
loc_admin_state 'estado',
web_address as 'pagina_web',
loc_admin_city as 'ciudad',
loc_admin_street1 as 'direccion',
loc_admin_street2 as 'complejo',
loc_admin_zip as 'codigo_postal'
from csv.primera_tabla WHERE provider_location_guid <> ' ' AND loc_phone <> ' ' AND loc_name <> ' ' AND loc_admin_state <> ' ' 
AND web_address <> ' ' AND loc_admin_city <> ' ' AND loc_admin_street1 <> ' ' AND  loc_admin_street2 <> ' ' AND loc_admin_zip <> ' ' ;
