use csv;
select distinct provider_location_guid as "provider1_id" ,
loc_store_no as "storage" ,
loc_admin_street1 as "location" 
from primera_tabla 
where loc_store_no <> "" and  loc_admin_street1 <>"" ;