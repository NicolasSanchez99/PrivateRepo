INSERT ignore sars_db.reporte SELECT rand() as 'id_reporte', MMWR_week as 'tasa_mortalidad',
Location as 'estado',
date_type as 'tipo_dato',
Administered_daily_change_report as 'reporte_diario',
Administered_daily_change_report_7dayroll as 'reporte_semanal',
Series_Complete_Daily as 'carnet_completo_diario',
Series_Complete_Cumulative as 'carnet_completo_acumulativo',
Series_Complete_Day_Rolling_Average as 'carnte_completo_semanal',
loc_admin_zip as 'eps'
from csv.segunda_tabla sg join csv.primera_tabla pr on sg.Location = pr.loc_admin_proveedor_has_epsstate WHERE MMWR_week <> ' ' AND Location <> ' ' AND
date_type <> ' ' AND Administered_daily_change_report <> ' ' AND Administered_daily_change_report_7dayroll <> ' ' AND Series_Complete_Daily <> ' ' AND
Series_Complete_Cumulative <> ' ' AND Series_Complete_Day_Rolling_Average <> ' ' AND loc_admin_zip <> ' ';

SELECT MMWR_week as 'tasa_mortalidad',
Location as 'estado',
date_type as 'tipo_dato',
Administered_daily_change_report as 'reporte_diario',
Administered_daily_change_report_7dayroll as 'reporte_semanal',
Series_Complete_Daily as 'carnet_completo_diario',
Series_Complete_Cumulative as 'carnet_completo_acumulativo',
Series_Complete_Day_Rolling_Average as 'carnte_completo_semanal',
loc_admin_zip as 'eps'
from csv.segunda_tabla sg join csv.primera_tabla pr on sg.Location = pr.loc_admin_state WHERE MMWR_week <> ' ' AND Location <> ' ' AND
date_type <> ' ' AND Administered_daily_change_report <> ' ' AND Administered_daily_change_report_7dayroll <> ' ' AND Series_Complete_Daily <> ' ' AND
Series_Complete_Cumulative <> ' ' AND Series_Complete_Day_Rolling_Average <> ' ' AND loc_admin_zip <> ' ' ;


