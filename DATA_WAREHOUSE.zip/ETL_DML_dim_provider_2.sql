use csv;

select distinct provider_location_guid as "provider2_id" ,
loc_store_no as "storage" ,
loc_phone as "phone" 
from primera_tabla 
where loc_store_no <> "" and  loc_phone <>"" ;