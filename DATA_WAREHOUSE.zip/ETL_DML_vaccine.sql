use csv;
select distinct 
ndc as "ndc"   ,
med_name as "name" ,
Location as "state"
from csv.primera_tabla pt join csv.segunda_tabla st on  pt.loc_admin_state= st.Location
where ndc<> "" ;

