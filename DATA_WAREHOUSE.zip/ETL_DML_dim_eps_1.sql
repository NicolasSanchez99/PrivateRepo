use csv;
select distinct loc_admin_zip as 'eps1_id' ,
loc_admin_state as 'state' ,
loc_name as 'address' ,
CAST(latitude AS DECIMAL(20,5))  as 'latitude' 
from csv.primera_tabla
where loc_admin_zip <> "" and
 latitude <> 0;

drop database sars_dw;
use sars_dw;
insert sars_dw.dim_eps_1 select distinct loc_admin_zip as 'eps1_id' ,
loc_admin_state as 'state' ,
loc_name as 'address' ,
CAST(latitude AS DECIMAL(20,5))  as 'latitude' 
from csv.primera_tabla
where loc_admin_zip <> "" and
 latitude <> 0;



