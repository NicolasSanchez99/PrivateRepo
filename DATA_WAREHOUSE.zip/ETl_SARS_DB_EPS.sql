insert ignore sars_db.eps select distinct loc_admin_zip as 'nit', 
loc_name as 'nombre', 
Admin_Dose_1_Daily as 'fvacuna_diaria_administrada', 
DateV as 'fecha_aplicacion',
Admin_Dose_1_Daily as 'vacuna_primera_dosis_diaria',
Admin_Dose_1_Day_Rolling_Average as 'vacuna_primera_dosis_semanal',
Admin_Dose_1_Cumulative as 'vacuna_primera_dosis_acumulada',
Administered_7_Day_Rolling_Average as 'vacuna_semanal_administrada',
Administered_Cumulative as 'vacuna_acumulada',
longitude as 'longitude',
latitude as 'latitude',
loc_admin_state as 'state'
from csv.primera_tabla pr join csv.segunda_tabla sg on pr.loc_admin_state = sg.Location WHERE loc_admin_zip <> ' ' and 
loc_name <> ' ' and DateV <> ' ' and Admin_Dose_1_Daily <> ' ' and Admin_Dose_1_Day_Rolling_Average <> ' ' and Admin_Dose_1_Cumulative <> ' ' 
and Administered_7_Day_Rolling_Average <> ' ' and Administered_Cumulative <> ' '  and longitude <> ' ' and
latitude <> ' ' and loc_admin_state <> ' ';

select loc_admin_zip as 'nit', 
loc_name as 'nombre', 
Admin_Dose_1_Daily as 'fvacuna_diaria_administrada', 
DateV as 'fecha_aplicacion',
Admin_Dose_1_Daily as 'vacuna_primera_dosis_diaria',
Admin_Dose_1_Day_Rolling_Average as 'vacuna_primera_dosis_semanal',
Admin_Dose_1_Cumulative as 'vacuna_primera_dosis_acumulada',
Administered_7_Day_Rolling_Average as 'vacuna_semanal_administrada',
Administered_Cumulative as 'vacuna_acumulada',
longitude as 'longitude',
latitude as 'latitude',
loc_admin_state as 'state'
from csv.primera_tabla pr join csv.segunda_tabla sg on pr.loc_admin_state = sg.Location WHERE loc_admin_zip <> ' ' and 
loc_name <> ' ' and DateV <> ' ' and Admin_Dose_1_Daily <> ' ' and Admin_Dose_1_Day_Rolling_Average <> ' ' and Admin_Dose_1_Cumulative <> ' ' 
and Administered_7_Day_Rolling_Average <> ' ' and Administered_Cumulative <> ' '  and longitude <> ' ' and
latitude <> ' ' and loc_admin_state <> ' ';



