INSERT sars_db.vacuna SELECT ndc as 'id_acuna',
quantity_last_updated as 'fecha_ingreso',
med_name as 'nombre',
supply_level as 'cant_dosis',
in_stock as 'disponibilidad'
from csv.primera_tabla WHERE ndc <> ' ' AND quantity_last_updated <> ' '
AND med_name <> ' ' AND supply_level <> ' ' AND in_stock <> ' ';

SELECT ndc as 'id_acuna',
quantity_last_updated as 'fecha_ingreso',
med_name as 'nombre',
supply_level as 'cant_dosis',
in_stock as 'disponibilidad'
from csv.primera_tabla WHERE ndc <> ' ' AND quantity_last_updated <> ' '
AND med_name <> ' ' AND supply_level <> ' ' AND in_stock <> ' ';

