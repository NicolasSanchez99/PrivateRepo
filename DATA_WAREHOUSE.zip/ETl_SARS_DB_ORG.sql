select distinct loc_admin_street1 as 'ubicacion_almacen',
monday_hours as 'lunes',
tuesday_hours as 'martes',
wednesday_hours as 'miercoles',
thursday_hours as 'jueves',
friday_hours as 'viernes',
saturday_hours as 'sabado',
sunday_hours as 'domingo',
loc_admin_zip AS 'eps' 
from csv.primera_tabla WHERE loc_admin_street1 <> ' ' AND monday_hours <> ' ' AND tuesday_hours <> ' ' AND tuesday_hours <> ' ' 
AND wednesday_hours <> ' ' AND thursday_hours <> ' ' AND friday_hours <> ' ' AND saturday_hours <> ' ' AND sunday_hours <> ' ' AND
loc_admin_zip <> ' ' ;

INSERT sars_db.organismo_aplicador  select distinct loc_admin_street1 as 'ubicacion_almacen',
monday_hours as 'lunes',
tuesday_hours as 'martes',
wednesday_hours as 'miercoles',
thursday_hours as 'jueves',
friday_hours as 'viernes',
saturday_hours as 'sabado',
sunday_hours as 'domingo',
loc_admin_zip AS 'eps' 
from csv.primera_tabla WHERE loc_admin_street1 <> ' ' AND monday_hours <> ' ' AND tuesday_hours <> ' ' AND tuesday_hours <> ' ' 
AND wednesday_hours <> ' ' AND thursday_hours <> ' ' AND friday_hours <> ' ' AND saturday_hours <> ' ' AND sunday_hours <> ' ' AND
loc_admin_zip <> ' ' ;

