/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.seguridad.controlador.persistencia;

import co.edu.usbbog.seguridad.vista.InterfazAdmin;
import co.edu.usbbog.seguridad.vista.Joption;
import co.edu.usbbog.seguridad.vista.Joptionx;
import java.sql.*;
import javax.swing.JOptionPane;
import co.edu.usbbog.seguridad.vista.Login;
import co.edu.usbbog.seguridad.controlador.logic.Pri;
import co.edu.usbbog.seguridad.controlador.logic.RolDAO;
import static co.edu.usbbog.seguridad.vista.Login.Lista;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Acceso {

    Joption icon = new Joption();
    Joptionx save = new Joptionx();
    Pri pri = new Pri();
    private Conexion conexion;
    private Conexion conexion2;

    public Acceso(String usuario, String pass) {
        this.conexion = new Conexion("127.0.0.1",3306,"c_inv_db",usuario,pri.codify(pass));
        this.conexion2 = new Conexion("127.0.0.1",3306,"mysql",usuario,pri.codify(pass));
    }
//    
//        public Acceso(String user, String pass) {
//        this.conexion = new Conexion("127.0.0.1",3306,"c_inv_db",user,pass);
//        this.conexion2 = new Conexion("127.0.0.1",3306,"mysql",user,pass);
//    }

    //String secretKey = "ClaveTRSD";

    public void acceso( String contraseña) {

//        Connection conexion = null;
//        Statement consulta = null;
//        ResultSet tabla = null;

            try {
                if (this.conexion2.conectar()) {
                    String sql = "SELECT user,authentication_string FROM user WHERE authentication_string = PASSWORD('"+
                         pri.codify(contraseña)+
                        "');";
                    Connection con = this.conexion2.getCon();
                    Statement stm = con.createStatement();
                    ResultSet rs = (ResultSet) stm.executeQuery(sql);
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(null, "BIENVENIDO ADMIN!!", "BIENVENIDO!!", JOptionPane.PLAIN_MESSAGE, icon);
                        InterfazAdmin as = new InterfazAdmin();
                        as.setVisible(true);
                        rs.close();
                        stm.close();
                        con.close();

                    } else{
                        JOptionPane.showMessageDialog(null, "DATOS INCORRECTOS O NO HA SIDO REGISTRADO!", "ERROR", JOptionPane.ERROR_MESSAGE, save);
                        Login.contraseña.setText("");
                        rs.close();
                        stm.close();
                        con.close();
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "ACCESO DENEGADO O NO HA SIDO REGISTRADO");
                }


                  
                    } catch (SQLException ex) {
                        
                        Logger.getLogger(RolDAO.class.getName()).log(Level.SEVERE, null, ex);

            }
    }

   public void accesoinv( String contraseña) {

//        Connection conexion = null;
//        Statement consulta = null;
//        ResultSet tabla = null;

            try {
                if (this.conexion2.conectar()) {
                    String sql = "SELECT user,authentication_string FROM user WHERE authentication_string = PASSWORD('"+
                         pri.codify(contraseña)+
                        "');";
                    Connection con = this.conexion2.getCon();
                    Statement stm = con.createStatement();
                    ResultSet rs = (ResultSet) stm.executeQuery(sql);
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(null, "BIENVENIDO USER!!", "BIENVENIDO!!", JOptionPane.PLAIN_MESSAGE, icon);
                        InterfazAdmin as = new InterfazAdmin();
                        as.setVisible(true);
                        rs.close();
                        stm.close();
                        con.close();

                    } else{
                        JOptionPane.showMessageDialog(null, "DATOS INCORRECTOS O NO HA SIDO REGISTRADO!", "ERROR", JOptionPane.ERROR_MESSAGE, save);
                        Login.contraseña.setText("");
                        rs.close();
                        stm.close();
                        con.close();
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "ACCESO DENEGADO O NO HA SIDO REGISTRADO POR EL ADMIN");
                }


                  
                    } catch (SQLException ex) {
                Logger.getLogger(RolDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    public boolean validarSesion() {
        int acceso = Lista.getSelectedIndex();
        switch (acceso) {
            case 1:
                return true;
            case 2:
                return false;
            default:
                return false;
        }
    }
}
