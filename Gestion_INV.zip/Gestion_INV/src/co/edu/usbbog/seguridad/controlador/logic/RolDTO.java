/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.seguridad.controlador.logic;

import co.edu.usbbog.seguridad.modelo.Rol;
import javax.swing.JTable;

/**
 *
 * @author nicos
 */
public interface RolDTO {
    
    public boolean create(Rol rol);

    public boolean edit(Rol rol);

    public boolean remove(String email);

    public Rol find(String email);

    public int count();

    public void buscarRol(JTable tabla, String email);

    public void listarRol(JTable tabla);

     public void findRol(JTable tabla, String email);
}
