/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.seguridad.controlador.logic;

import co.edu.usbbog.seguridad.controlador.persistencia.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author nicos
 */
public class AuditoriaDAO implements AuditoriaDTO{
    private Conexion conexion;
    private Conexion conexion2;
        private Pri cyp;

    public AuditoriaDAO(String user, String pass) {
        this.cyp = new Pri();
        this.conexion = new Conexion("127.0.0.1", 3306, "c_inv_db", user, cyp.codify(pass));
        this.conexion2 = new Conexion("127.0.0.1", 3306, "mysql", user, cyp.codify(pass));
    }
    
    
    @Override
    public void show(JTable tabla) {
         if (this.conexion.conectar()) {
            Connection con = this.conexion.getCon();
            DefaultTableModel model;
            String[] columnas = {"ACCION", "FECHA", "USUARIO"};
            model = new DefaultTableModel(null, columnas);
            String sql = "select * from auditoria";
            String[] filas = new String[3];
            Statement st = null;
            ResultSet rs = null;
            try {
                st = con.createStatement();
                rs = st.executeQuery(sql);
                while (rs.next()) {
                    for (int i = 0; i < 3; i++) {
                        filas[i] = rs.getString(i + 1);
                    }
                    model.addRow(filas);
                }
                tabla.setModel(model);
            } catch (SQLException e) {
            }

        }
    }
    
}
