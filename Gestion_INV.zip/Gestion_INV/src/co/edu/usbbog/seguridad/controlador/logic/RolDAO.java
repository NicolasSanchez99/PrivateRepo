/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.seguridad.controlador.logic;

import co.edu.usbbog.seguridad.controlador.persistencia.Conexion;
import co.edu.usbbog.seguridad.modelo.Rol;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;

/**
 *
 * @author nicos
 */
public class RolDAO implements RolDTO{
    
    private Conexion conexion;

    public RolDAO() {
        this.conexion = new Conexion("127.0.0.1",3306,"c_inv_db","root","password");
    }

    @Override
    public boolean create(Rol rol) {
         boolean seHizo = false;
        try {
            if (this.conexion.conectar()) {
                String sql = "INSERT INTO rol(id_rol,nombre) VALUES("
                        + rol.getIdRol()+ ",'"
                        + rol.getNombre() 
                        + "');";
                System.out.println(sql);
                Connection con = this.conexion.getCon();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.execute();
                ps.close();
                con.close();
                seHizo = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(RolDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }

    @Override
    public boolean edit(Rol rol) {
        boolean seHizo = false;
        try {
            if (this.conexion.conectar()) {
                String sql = "UPDATE rol SET nombre ='"
                        + rol.getNombre()+"'"
                        + " where id_rol =" + rol.getIdRol()+ ";";
                System.out.println(sql);
                Connection con = this.conexion.getCon();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.executeUpdate();
                ps.close();
                con.close();
                seHizo = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(RolDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }

    @Override
    public boolean remove(String email) {
        boolean seHizo = false;
        try {
            if (this.conexion.conectar()) {
         
                    String sql = "DELETE from rol WHERE id_rol ="
                            + email + ";";
                    Connection con = this.conexion.getCon();
                    PreparedStatement ps = con.prepareStatement(sql);
                    System.out.println(sql);
                    ps.execute();
                    ps.close();
                    con.close();
                    seHizo = true;
                }
            
        } catch (SQLException ex) {
            Logger.getLogger(RolDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }

    @Override
    public Rol find(String email) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int count() {
        int counter = 0;
        try {
            if (this.conexion.conectar()) {
                String sql = "SELECT COUNT(id_rol) FROM rol";
                Connection con = this.conexion.getCon();
                Statement stm = con.createStatement();
                ResultSet rs = (ResultSet) stm.executeQuery(sql);
                while (rs.next()) {
                    counter = rs.getInt(1);
                    System.out.println(counter);
                }
                rs.close();
                stm.close();
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(RolDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return counter;
    }

    @Override
    public void buscarRol(JTable tabla, String email) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void listarRol(JTable tabla) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void findRol(JTable tabla, String email) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
//    public static void main(String[] args) {
//        RolDAO r= new RolDAO(); 
//        System.out.println((Math.random() * 1000) + 1);
//    }
//    
}
