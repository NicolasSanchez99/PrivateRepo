/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.seguridad.controlador.persistencia;

/**
 *
 * @author spark
 */



import static java.lang.Class.forName;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion { //se declararn variables

    private final String ip;
    private final int port;
    private final String user;
    private final String db;
    private final String password;
    //private final String path;
    private Connection con;

    public Conexion(String ip, int port, String db, String user, String password) { //se asignan los datos especificos
        this.ip = ip;
        this.port = port;
        this.db = db;
        this.user = user;
        this.password = password;
    }

     public boolean conectar() {
        String path
                = "jdbc:mysql://" + this.ip
                + ":" + this.port
                + "/" + this.db
                + "?user=" + this.user
                + "&password=" + this.password;
        //System.out.println(path);
        try {
            this.con = (com.mysql.jdbc.Connection) DriverManager.getConnection(path);
            if (this.con != null) {
                System.out.println("Conecto");

                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public com.mysql.jdbc.Connection getCon() {
        return (com.mysql.jdbc.Connection) con;
    }

    public void disconnect() {
        con = null;
        if (con == null) {
            System.out.println("Conexion terminada");
        }
    }
//    public static void main(String[] args) {
//        Conexion c= new Conexion("127.0.0.1",3306,"c_inv_db","root","password");
//        c.conectar();
//    }
}


