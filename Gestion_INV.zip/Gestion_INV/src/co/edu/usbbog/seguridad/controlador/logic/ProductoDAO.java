/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.seguridad.controlador.logic;

import co.edu.usbbog.seguridad.controlador.persistencia.Conexion;
import co.edu.usbbog.seguridad.modelo.Producto;
import co.edu.usbbog.seguridad.modelo.Usuario;
import co.edu.usbbog.seguridad.vista.Login;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author nicos
 */
public class ProductoDAO implements ProductoDTO {

    private Conexion conexion;
    private Conexion conexion2;
    private RolDAO rolDao;
    private Pri cyp;

    public ProductoDAO(String user, String pass) {
        this.cyp = new Pri();
        this.conexion = new Conexion("127.0.0.1", 3306, "c_inv_db", user, cyp.codify(pass));
        this.conexion2 = new Conexion("127.0.0.1", 3306, "mysql", user, cyp.codify(pass));
        // this.rolDao = new RolDAO();

    }

    @Override
    public boolean create(Producto rol) {
        boolean seHizo = false;
        try {
            if (this.conexion.conectar()) {
                String sql = "INSERT INTO producto(serial,nombre,marca,fecha_ingreso,precio,observaciones,garantia,estado,usuario_Id_usuario) VALUES("
                        + rol.getSerial() + ",'"
                        + rol.getNombre() + "','"
                        + rol.getMarca() + "',"
                        + "NOW()" + ",'"
                        + rol.getPrecio() + "','"
                        + rol.getObservaciones() + "','"
                        + rol.getGarantia() + "','"
                        + rol.getEstado() + "',"
                        + rol.getUsuarioIdusuario()
                        + ");";
                System.out.println(sql);
                Connection con = this.conexion.getCon();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.execute();
                ps.close();
                con.close();
                seHizo = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }

    @Override
    public boolean edit(int serial, String estado) {
        boolean seHizo = false;
        try {
            if (this.conexion.conectar()) {
                String sql = "UPDATE producto SET estado ='"
                        + estado
                        + "' where serial =" + serial + ";";
                System.out.println(sql);
                Connection con = this.conexion.getCon();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.executeUpdate();
                ps.close();
                con.close();
                seHizo = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }

    @Override
    public boolean remove(int email) {
        boolean seHizo = false;
        try {
            if (this.conexion.conectar()) {
                String sql = "DELETE from producto WHERE serial ="
                        + email + ";";
                Connection con = this.conexion.getCon();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.execute();
                ps.close();
                con.close();
                seHizo = true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }

    @Override
    public Producto find(int email) {
        Producto p = null;
        String nombre, marca, fecha, precio, obs, garantia, estado;
        int serial, id;
        try {
            if (this.conexion.conectar()) {
                String sql = "select * from producto WHERE serial = '"
                        + email + "' order by serial";
                Connection con = this.conexion.getCon();
                Statement stm = con.createStatement();
                ResultSet rs = (ResultSet) stm.executeQuery(sql);
                System.out.println(sql);
                while (rs.next()) {
                    serial = rs.getInt(1);
                    nombre = rs.getString(2);
                    marca = rs.getString(3);
                    fecha = rs.getString(4);
                    precio = rs.getString(5);
                    obs = rs.getString(6);
                    garantia = rs.getString(7);
                    estado = rs.getString(8);
                    id = rs.getInt(9);
                    p = new Producto(serial, nombre, marca, fecha, precio, garantia, estado, id);
                    JOptionPane.showMessageDialog(null, p.toString());
                }
                rs.close();
                stm.close();
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }

    @Override
    public int count() {
        int counter = 0;
        try {
            if (this.conexion.conectar()) {
                String sql = "SELECT COUNT(serial) FROM producto";
                Connection con = this.conexion.getCon();
                Statement stm = con.createStatement();
                ResultSet rs = (ResultSet) stm.executeQuery(sql);
                while (rs.next()) {
                    counter = rs.getInt(1);
                    String pass="Hay "+counter+" productos registrados";
                    JOptionPane.showMessageDialog(null, pass);
                }
                rs.close();
                stm.close();
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return counter;
    }

    @Override
    public void listarProducto(JTable tabla) {
         if (this.conexion.conectar()) {
            Connection con = this.conexion.getCon();
            DefaultTableModel model;
            String[] columnas = {"SERIAL", "NOMBRE", "MARCA", "FECHA INGRESO", "PRECIO","OBSERVACIONES","GARANTIA","ESTADO","ID DE USUARIO"};
            model = new DefaultTableModel(null, columnas);
            String sql = "select * from producto order by serial";
            String[] filas = new String[9];
            Statement st = null;
            ResultSet rs = null;
            try {
                st = con.createStatement();
                rs = st.executeQuery(sql);
                while (rs.next()) {
                    for (int i = 0; i < 9; i++) {
                        filas[i] = rs.getString(i + 1);
                    }
                    model.addRow(filas);
                }
                tabla.setModel(model);
            } catch (SQLException e) {
            }

        }
    }

}
