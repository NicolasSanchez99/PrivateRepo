/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.seguridad.controlador.logic;

import co.edu.usbbog.seguridad.controlador.persistencia.Conexion;
import co.edu.usbbog.seguridad.modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author nicos
 */
public class UsuarioDAO implements UsuarioDTO{
    
    private Conexion conexion;
     private Conexion conexion2;
    private RolDAO rolDao;
    private Pri cyp;

    public UsuarioDAO(String user, String pass) {
        this.cyp= new Pri();
        this.conexion = new Conexion("127.0.0.1",3306,"c_inv_db",user,cyp.codify(pass));
        this.conexion2 = new Conexion("127.0.0.1",3306,"mysql",user,cyp.codify(pass));
       // this.rolDao = new RolDAO();
        
    }

    @Override
    public boolean create(Usuario user) {
                boolean seHizo = false;
        try {
            if (this.conexion.conectar()) {
                String sql = "INSERT INTO usuario(Id_usuario,nombre,apellido,email,contraseña,rol_id_rol) VALUES("
                        + user.getIdusuario()+ ",'"
                        + user.getNombre() + "','"
                        + user.getApellido() + "','"
                        + user.getEmail()+ "','"
                        + cyp.codify(user.getContraseña())+"',"
                        + user.getRolIdRol()
                        + ");";
                System.out.println(sql);
                Connection con = this.conexion.getCon();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.execute();
                ps.close();
                con.close();
                seHizo = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }

    @Override
    public boolean edit(Usuario rol) {
        boolean seHizo = false;
        try {
            if (this.conexion.conectar()) {
                String sql = "UPDATE usuario SET Id_usuario ='"
                        + rol.getIdusuario()+ "', nombre='"
                        + rol.getNombre() + "', apellido='"
                        + rol.getApellido() + "', email='"
                        + rol.getEmail()+"', contraseña='"
                        + cyp.codify(rol.getContraseña())+"', rol_id_rol="
                        +rol.getRolIdRol()
                        + " where Id_usuario ='" + rol.getIdusuario()+ "';";
                System.out.println(sql);
                Connection con = this.conexion.getCon();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.executeUpdate();
                ps.close();
                con.close();
                seHizo = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }

    @Override
    public boolean remove(int email) {
         boolean seHizo = false;
        try {
            if (this.conexion.conectar()) {
         
                    String sql = "DELETE from usuario WHERE Id_usuario ="
                            + email + ";";
                    Connection con = this.conexion.getCon();
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.execute();
                    ps.close();
                    con.close();
                    seHizo = true;
                }
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }

    @Override
    public Usuario find(int email) {
       Usuario p = null;
        String nombre, apellido;
        int edad;
        try {
            if (this.conexion.conectar()) {
                String sql = "select nombre,apellido from usuario WHERE Id_usuario = '"
                        + email + "' order by Id_usuario";
                Connection con = this.conexion.getCon();
                Statement stm = con.createStatement();
                ResultSet rs = (ResultSet) stm.executeQuery(sql);
                System.out.println(sql);
                while (rs.next()) {
                    nombre = rs.getString(1);
                    apellido = rs.getString(2);
                    p = new Usuario(nombre, apellido);
                    JOptionPane.showMessageDialog(null, p.toString());
                }
                rs.close();
                stm.close();
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }

    @Override
    public int count() {
        int counter = 0;
        try {
            if (this.conexion.conectar()) {
                String sql = "SELECT COUNT(Id_usuario) FROM usuario";
                Connection con = this.conexion.getCon();
                Statement stm = con.createStatement();
                ResultSet rs = (ResultSet) stm.executeQuery(sql);
                while (rs.next()) {
                    counter = rs.getInt(1);
                    String pass="Hay "+counter+" usuarios";
                    JOptionPane.showMessageDialog(null, pass);
                }
                rs.close();
                stm.close();
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return counter;
    }

    @Override
    public void listarUsuario(JTable tabla) {
         if (this.conexion.conectar()) {
            Connection con = this.conexion.getCon();
            DefaultTableModel model;
            String[] columnas = {"Id_usuario", "nombre", "apellido", "email"};
            model = new DefaultTableModel(null, columnas);
            String sql = "select * from usuario order by Id_usuario";
            String[] filas = new String[4];
            Statement st = null;
            ResultSet rs = null;
            try {
                st = con.createStatement();
                rs = st.executeQuery(sql);
                while (rs.next()) {
                    for (int i = 0; i < 4; i++) {
                        filas[i] = rs.getString(i + 1);
                    }
                    model.addRow(filas);
                }
                tabla.setModel(model);
            } catch (SQLException e) {
            }

        }
    }
   
    @Override
    public boolean createBDA(Usuario rol) {
                 boolean seHizo = false;
        try {
            if (this.conexion2.conectar()) {
                String sql = "CREATE USER '"+rol.getNombre()+"'@'localhost' IDENTIFIED BY '"+cyp.codify(rol.getContraseña())+"';";
                System.out.println(sql);
                Connection con = this.conexion2.getCon();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.execute();
                ps.close();
                con.close();
                seHizo = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }
//        public static void main(String[] args) {
//        Usuario rol= new Usuario(1456, "Lola","sanchez" , "qwe", "HPTA",1);
//        UsuarioDAO t = new UsuarioDAO();
//        String p= "1";
//        t.createBD(rol);
//    }

    @Override
    public boolean PrivAdmin(Usuario rol) {
          boolean seHizo = false;
        try {
            if (this.conexion2.conectar()) {
                String sql = "GRANT ALL ON *.* TO "+rol.getNombre()+"@localhost IDENTIFIED BY " +"'"+ cyp.codify(rol.getContraseña())+"';";
                System.out.println(sql);
                Connection con = this.conexion2.getCon();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.execute();
                ps.close();
                con.close();
                seHizo = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }
    

    @Override
    public boolean PrivUser(Usuario rol) {
          boolean seHizo = false;
        try {
            if (this.conexion2.conectar()) {
                String sql = "GRANT ALL ON *.* TO "+rol.getNombre()+"@localhost IDENTIFIED BY " +"'"+ cyp.codify(rol.getContraseña())+"';";
                System.out.println(sql);
                Connection con = this.conexion2.getCon();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.execute();
                ps.close();
                con.close();
                seHizo = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return seHizo;
    }

    @Override
    public Usuario findID(String email) {
        Usuario p = null;
        String nombre, apellido;
        int id;
        try {
            if (this.conexion.conectar()) {
                String sql = "select Id_usuario from usuario WHERE nombre = '"
                        + email + "' order by Id_usuario";
                Connection con = this.conexion.getCon();
                Statement stm = con.createStatement();
                ResultSet rs = (ResultSet) stm.executeQuery(sql);
                System.out.println(sql);
                while (rs.next()) {
                    id=rs.getInt(1);
                    p = new Usuario(id);
                    JOptionPane.showMessageDialog(null, p.toString());
                }
                rs.close();
                stm.close();
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }
    
}
