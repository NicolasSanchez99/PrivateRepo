/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.usbbog.seguridad.controlador.logic;


import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JOptionPane;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;

/**
 *
 * @author nicos
 */
public class Pri {
 public String codify(String cadena) {
        String encript = "";
        try {
            encript = DigestUtils.md5Hex(cadena);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Salio mal" + ex);
        }
        return encript;
    }

    public String decodify(String secret, String cadena) {
        String dencript = "";
        try {
            byte[] message = Base64.decodeBase64(cadena.getBytes("utf-8"));
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte[] digestPass = md5.digest(secret.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestPass, 24);
            SecretKey key = new SecretKeySpec(keyBytes, "DESede");
            Cipher decipher = Cipher.getInstance("DESede");
            decipher.init(Cipher.DECRYPT_MODE, key);
            byte[] plainText = decipher.doFinal(message);
            dencript = new String(plainText, "UTF-8");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "SAlio mal" + ex);
        }
        return dencript;
    }
    
//    public static void main(String[] args) {
//        Pri p= new Pri();
//        System.out.println(p.codify("Jose")); 
//
//        
//    }
}
